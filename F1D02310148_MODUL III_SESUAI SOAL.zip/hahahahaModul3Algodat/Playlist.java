public class Playlist {
    private Lagu head;

    public Playlist() {
        this.head = null;
    }

    public void insertLagu(String judul, String artis, int tahunRilis, int durasiMenit, int durasiDetik, String genre) {
        Lagu newLagu = new Lagu(judul, artis, tahunRilis, durasiMenit, durasiDetik, genre);
        if (head == null) {
            head = newLagu;
        } else {
            Lagu temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newLagu;
            newLagu.prev = temp;
        }
    }

    public void urutDurasi() {
        if (head == null) return;

        boolean swapped;
        do {
            swapped = false;
            Lagu current = head;
            while (current.next != null) {
                if (current.durasiMenit > current.next.durasiMenit || 
                    (current.durasiMenit == current.next.durasiMenit && current.durasiDetik > current.next.durasiDetik)) {
                    swap(current, current.next);
                    swapped = true;
                }
                current = current.next;
            }
        } while (swapped);
    }

    public void urutTahunRilis() {
        if (head == null) return;

        for (Lagu i = head; i != null; i = i.next) {
            Lagu max = i;
            for (Lagu j = i.next; j != null; j = j.next) {
                if (j.tahunRilis > max.tahunRilis) {
                    max = j;
                }
            }
            if (max != i) {
                swap(i, max);
            }
        }
    }

    private void swap(Lagu a, Lagu b) {
        String tempJudul = a.judul;
        String tempArtis = a.artis;
        int tempTahunRilis = a.tahunRilis;
        int tempDurasiMenit = a.durasiMenit;
        int tempDurasiDetik = a.durasiDetik;
        String tempGenre = a.genre;

        a.judul = b.judul;
        a.artis = b.artis;
        a.tahunRilis = b.tahunRilis;
        a.durasiMenit = b.durasiMenit;
        a.durasiDetik = b.durasiDetik;
        a.genre = b.genre;

        b.judul = tempJudul;
        b.artis = tempArtis;
        b.tahunRilis = tempTahunRilis;
        b.durasiMenit = tempDurasiMenit;
        b.durasiDetik = tempDurasiDetik;
        b.genre = tempGenre;
    }

    public Lagu searchLagu(String judul) {
        Lagu current = head;
        while (current != null) {
            if (current.judul.equalsIgnoreCase(judul)) {
                return current;
            }
            current = current.next;
        }
        return null;
    }

    public void tampilkanPlaylist() {
        if (head == null) {
            System.out.println("There is no song in the playlist yet");
            return;
        }
        Lagu current = head;
        int index = 1;
        while (current != null) {
            System.out.println("===========================================================");
            System.out.printf("%4d | %s - %s (%d)\n", index, current.artis, current.judul, current.tahunRilis);
            System.out.printf("    %d:%02d              %s\n", current .durasiMenit, current.durasiDetik, current.genre);
            current = current.next;
            index++;
        }
        System.out.println("===========================================================");
    }
}