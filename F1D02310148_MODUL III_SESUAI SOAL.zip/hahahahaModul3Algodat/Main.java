import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Playlist playlist = new Playlist();
        
        // Menambahkan 50 lagu ke dalam playlist
        tambahLagu(playlist);
        
        // Menampilkan playlist awal
        System.out.println("==================================================");
        System.out.println("||                  LOL Playlist                ||");
        System.out.println("==================================================");
        playlist.tampilkanPlaylist();
        System.out.println("==================================================");

        // Mengurutkan berdasarkan durasi
        long startTime = System.nanoTime();
        playlist.urutDurasi();
        long endTime = System.nanoTime();
        System.out.println("Bubble sort: " + (endTime - startTime) + " nanodetik");
        
        System.out.println("\n# Tampilan setelah diurutkan berdasarkan durasi (Asc):");
        System.out.println("==================================================");
        playlist.tampilkanPlaylist();
        System.out.println("==================================================");

        // Mengurutkan berdasarkan tahun rilis
        startTime = System.nanoTime();
        playlist.urutTahunRilis();
        endTime = System.nanoTime();
        System.out.println("Algoritma Selection sort: " + (endTime - startTime) + " nanodetik");
        
        System.out.println("\n# Tampilan setelah diurutkan berdasarkan tahun rilis (Desc):");
        System.out.println("==================================================");
        playlist.tampilkanPlaylist();
        System.out.println("==================================================");

        // Mencari lagu
        Scanner scanner = new Scanner(System.in);
        System.out.print("Judul lagu yang ingin dicari: ");
        String judul = scanner.nextLine();
        Lagu foundLagu = playlist.searchLagu(judul);
        if (foundLagu != null) {
            System.out.println("Lagu yang sesuai dengan judul '" + judul + "' ditemukan:");
            System.out.printf("    %s - %s (%d)\n", foundLagu.artis, foundLagu.judul, foundLagu.tahunRilis);
            System.out.printf("    %d:%02d              %s\n", foundLagu.durasiMenit, foundLagu.durasiDetik, foundLagu.genre);
        } else {
            System.out.println("Lagu dengan judul '" + judul + "' tidak ditemukan.");
        }
        
        scanner.close();
    }

    private static void tambahLagu(Playlist playlist) {
        // Lagu Awal
        playlist.insertLagu("Piano Man", "Billy Joel", 1979, 5, 39, "Folk");
        playlist.insertLagu("Die With A Smile", "Bruno Mars dan Lady Gaga", 2024, 4, 11, "Pop");
        playlist.insertLagu("Nina", ".Feast", 2024, 4, 37, "Indonesian Rock");
        playlist.insertLagu("Bad", "Wave to Earth", 2023, 4, 23, "Korean Rock, Thai Indie");
        playlist.insertLagu("8 Letters", "Why Don't We", 2018, 3, 10, "Pop");
        playlist.insertLagu("There Is a Light That Never Goes Out", "The Smiths", 1986, 4, 4, "Indie");
        playlist.insertLagu("To the Bone", "Pamungkas", 2020, 5, 44, "Indonesian Indie");
        playlist.insertLagu("We are", "One Ok Rock", 2017, 4, 15, "Pop Rock");
        playlist.insertLagu("Small girl", "Lee Young Ji", 2024, 3, 9, "R&B");
        playlist.insertLagu("21 Guns", "Green Day", 2009, 5, 21, "Punk Pop");
        
        // Lana Del Rey
        playlist.insertLagu("Born to Die", "Lana Del Rey", 2012, 4, 42, "Pop");
        playlist.insertLagu("Summertime Sadness", "Lana Del Rey", 2012, 4, 25, "Pop");
        playlist.insertLagu("Young and Beautiful", "Lana Del Rey", 2013, 4, 28, "Pop");
        playlist.insertLagu("Love", "Lana Del Rey", 2017, 4, 22, "Pop");
        playlist.insertLagu("Doin' Time", "Lana Del Rey", 2019, 3, 36, "Reggae");
        playlist.insertLagu("Chemtrails Over the Country Club", "Lana Del Rey", 2021, 3, 30, "Pop");
        playlist.insertLagu("Blue Banisters", "Lana Del Rey", 2021, 3, 34, "Pop");
        playlist.insertLagu("Hope is a Dangerous Thing for a Woman Like Me to Have", "Lana Del Rey", 2019, 3, 12, "Pop");
        playlist.insertLagu("West Coast", "Lana Del Rey", 2014, 4, 16, "Pop");
        playlist.insertLagu("Ride", "Lana Del Rey", 2012, 4, 50, "Pop");

        //  Ziva Magnolya
        playlist.insertLagu("Satu", "Ziva Magnolya", 2020, 4, 10, "Pop");
        playlist.insertLagu("Cinta Luar Biasa", "Ziva Magnolya", 2020, 4, 20, "Pop");
        playlist.insertLagu("Kisahku", "Ziva Magnolya", 2021, 3, 45, "Pop");
        playlist.insertLagu("Bukan Cinta Biasa", "Ziva Magnolya", 2021, 4, 15, "Pop");
        playlist.insertLagu("Pupus", "Ziva Magnolya", 2021, 4, 30, "Pop");
        playlist.insertLagu("Sampai Jumpa", "Ziva Magnolya", 2022, 3, 50, "Pop");
        playlist.insertLagu("Kisah Kita", "Ziva Magnolya", 2022, 4, 5, "Pop");
        playlist.insertLagu("Bisa Aja", "Ziva Magnolya", 2022, 3, 40, "Pop");
        playlist.insertLagu("Takkan Ada Cinta yang Sia-Sia", "Ziva Magnolya", 2022, 4, 20, "Pop");
        playlist.insertLagu("Bisa Aja", "Ziva Magnolya", 2022, 3, 40, "Pop");

        // Henry Moodie
        playlist.insertLagu("Lose Control", "Henry Moodie", 2021, 3, 30, "Pop");
        playlist.insertLagu("Love Again", "Henry Moodie", 2022, 3, 50, "Pop");
        playlist.insertLagu("I Wish", "Henry Moodie", 2022, 3, 20, "Pop");
        playlist.insertLagu("All I Want", "Henry Moodie", 2022, 3, 15, "Pop");
        playlist.insertLagu("Goodbye", "Henry Moodie", 2022, 3, 40, "Pop");
        playlist.insertLagu("Home", "Henry Moodie", 2022, 3, 30, "Pop");
        playlist.insertLagu("Never Let You Go", "Henry Moodie", 2022, 3, 35, "Pop");
        playlist.insertLagu("Better Days", "Henry Moodie", 2022, 3, 50, "Pop");
        playlist.insertLagu("Runaway", "Aurora", 2015, 4, 10, "Pop");
        playlist.insertLagu(" The River", "Aurora", 2016, 4, 20, "Pop");
       
        // Raye
        playlist.insertLagu("Escapism", "Raye", 2022, 3, 40, "Pop");
        playlist.insertLagu("Natalie Don't", "Raye", 2021, 3, 30, "Pop");
        playlist.insertLagu("Call on Me", "Raye", 2021, 3, 20, "Pop");
        playlist.insertLagu("Regardless", "Raye", 2021, 3, 50, "Pop");
        playlist.insertLagu("Love Me Again", "Raye", 2022, 3, 45, "Pop");
        playlist.insertLagu("I Don't Want You", "Raye", 2022, 3, 35, "Pop");
        playlist.insertLagu("Body Talk", "Raye", 2022, 3, 25, "Pop");
        playlist.insertLagu("Shhh", "Raye", 2022, 3, 15, "Pop");
        playlist.insertLagu("The Thrill", "Raye", 2022, 3, 30, "Pop");
        playlist.insertLagu("Ice Cream Man", "Raye", 2022, 3, 20, "Pop");
    }
}