public class Lagu {
    String judul;
    String artis;
    int tahunRilis;
    int durasiMenit;
    int durasiDetik;
    String genre;
    Lagu prev;
    Lagu next;

    public Lagu(String judul, String artis, int tahunRilis, int durasiMenit, int durasiDetik, String genre) {
        this.judul = judul;
        this.artis = artis;
        this.tahunRilis = tahunRilis;
        this.durasiMenit = durasiMenit;
        this.durasiDetik = durasiDetik;
        this.genre = genre;
        this.prev = null;
        this.next = null;
    }
}
