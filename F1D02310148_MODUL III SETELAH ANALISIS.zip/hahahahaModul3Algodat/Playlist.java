public class Playlist {
    Lagu head;

    public void insertLagu(String judul, String artis, int tahunRilis, int durasiMenit, int durasiDetik, String genre) {
        Lagu newLagu = new Lagu(judul, artis, tahunRilis, durasiMenit, durasiDetik, genre);
        if (head == null) {
            head = newLagu;
        } else {
            Lagu temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newLagu;
            newLagu.prev = temp;
        }
    }

    public void tampilkanPlaylist() {
        Lagu temp = head;
        while (temp != null) {
            System.out.printf("%s - %s (%d)\n", temp.artis, temp.judul, temp.tahunRilis);
            System.out.printf("%d:%02d              %s\n", temp.durasiMenit, temp.durasiDetik, temp.genre);
            temp = temp.next;
        }
    }

    public void urutDurasi() {
        head = mergeSortByDurasi(head);
    }

    private Lagu mergeSortByDurasi(Lagu head) {
        if (head == null || head.next == null) return head;

        Lagu middle = getMiddle(head);
        Lagu nextOfMiddle = middle.next;
        middle.next = null;

        Lagu left = mergeSortByDurasi(head);
        Lagu right = mergeSortByDurasi(nextOfMiddle);

        return sortedMergeByDurasi(left, right);
    }

    private Lagu sortedMergeByDurasi(Lagu a, Lagu b) {
        if (a == null) return b;
        if (b == null) return a;

        Lagu result;
        if (a.durasiMenit < b.durasiMenit || 
           (a.durasiMenit == b.durasiMenit && a.durasiDetik <= b.durasiDetik)) {
            result = a;
            result.next = sortedMergeByDurasi(a.next, b);
            if (result.next != null) result.next.prev = result;
            result.prev = null;
        } else {
            result = b;
            result.next = sortedMergeByDurasi(a, b.next);
            if (result.next != null) result.next.prev = result;
            result.prev = null;
        }
        return result;
    }

    private Lagu getMiddle(Lagu head) {
        if (head == null) return head;

        Lagu slow = head, fast = head;
        while (fast.next != null && fast.next.next != null) {
            slow = slow.next;
            fast = fast.next.next;
        }
        return slow;
    }

    public void urutTahunRilis() {
        head = quickSortByTahunRilis(head, getLastNode(head));
    }

    private Lagu getLastNode(Lagu node) {
        while (node != null && node.next != null) {
            node = node.next;
        }
        return node;
    }

    private Lagu quickSortByTahunRilis(Lagu low, Lagu high) {
        if (high != null && low != high && low != high.next) {
            Lagu pivot = partition(low, high);
            quickSortByTahunRilis(low, pivot.prev);
            quickSortByTahunRilis(pivot.next, high);
        }
        return low;
    }

    private Lagu partition(Lagu low, Lagu high) {
        int pivot = high.tahunRilis;
        Lagu i = low.prev;
        
        for (Lagu j = low; j != high; j = j.next) {
            if (j.tahunRilis > pivot) {  // Descending order
                i = (i == null) ? low : i.next;
                swap(i, j);
            }
        }
        
        i = (i == null) ? low : i.next;
        swap(i, high);
        return i;
    }

    private void swap(Lagu a, Lagu b) {
        String tempJudul = a.judul;
        String tempArtis = a.artis;
        int tempTahun = a.tahunRilis;
        int tempDurasiMenit = a.durasiMenit;
        int tempDurasiDetik = a.durasiDetik;
        String tempGenre = a.genre;

        a.judul = b.judul;
        a.artis = b.artis;
        a.tahunRilis = b.tahunRilis;
        a.durasiMenit = b.durasiMenit;
        a.durasiDetik = b.durasiDetik;
        a.genre = b.genre;

        b.judul = tempJudul;
        b.artis = tempArtis;
        b.tahunRilis = tempTahun;
        b.durasiMenit = tempDurasiMenit;
        b.durasiDetik = tempDurasiDetik;
        b.genre = tempGenre;
    }

    public Lagu searchLagu(String judul) {
        Lagu temp = head;
        while (temp != null) {
            if (temp.judul.equalsIgnoreCase(judul)) {
                return temp;
            }
            temp = temp.next;
        }
        return null;
    }
}
